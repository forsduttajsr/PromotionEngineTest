using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using PromotionEnginePattern;
using System;
using System.Collections.Generic;

namespace Tests
{
    [TestClass]
    public class Tests
    {
        [TestMethod]
        public void ConvertPromotionChecker_ReturnDecimal()
        {

            Dictionary<String, int> d1 = new Dictionary<String, int>();
            d1.Add("A", 3);
            Dictionary<String, int> d2 = new Dictionary<String, int>();
            d2.Add("B", 2);
            Dictionary<String, int> d3 = new Dictionary<String, int>();
            d3.Add("C", 1);
            d3.Add("D", 1);

            

            Promotion mockPromotion = new Promotion(1, d1, 130);

            Order mockOrder1 = new Order(1, new List<Product>() { new Product("A"), new Product("A"), new Product("B"), new Product("B"), new Product("C"), new Product("D") });
            //Order mockOrder2 = new Order(2, new List<Product>() { new Product("A"), new Product("A"), new Product("A"), new Product("A"), new Product("A"), new Product("A"), new Product("B") });
            //Order mockOrder3 = new Order(3, new List<Product>() { new Product("A"), new Product("A"), new Product("D"), new Product("B"), new Product("B") });

            var mockGetTotalPrice = PromotionChecker.GetTotalPrice(mockOrder1, mockPromotion);
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(mockGetTotalPrice, 2);
        }
    }
}